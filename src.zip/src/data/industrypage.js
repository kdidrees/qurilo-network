export const industryToggleData = [
  {
    id: 1,
    heading: `What is a SAAS platform?`,
    desc: `SAAS platform is a cloud-based software service that allows users to access and use a variety of tools and functionality.`,
  },
  {
    id: 2,
    heading: `What is a SAAS platform?`,
    desc: `SAAS platform is a cloud-based software service that allows users to access and use a variety of tools and functionality.`,
  },
  {
    id: 3,
    heading: `What is a SAAS platform?`,
    desc: `SAAS platform is a cloud-based software service that allows users to access and use a variety of tools and functionality.`,
  },
  {
    id: 4,
    heading: `What is a SAAS platform?`,
    desc: `SAAS platform is a cloud-based software service that allows users to access and use a variety of tools and functionality.`,
  },
];
